component {
    <!--- Set your datasource name here --->
    property name="datasource" default="sg";
    
    /**
     * getMeals()
     * Returns a list of meals along with their ingredients.
     */
    remote any function getMeals() {
        var result = [];
        var mealsQ = queryExecute(
            "SELECT id, title, servings, mealType, created_at FROM meals ORDER BY title asc",
            {},
            { datasource = variables.datasource }
        );
        
        for (var i = 1; i <= mealsQ.recordCount; i++) {
            var meal = {
                id          : mealsQ.id[i],
                title       : mealsQ.title[i],
                servings    : mealsQ.servings[i],
                mealType    : mealsQ.mealType[i],
                created_at  : mealsQ.created_at[i],
                ingredients : []
            };
            var ingrQ = queryExecute(
                "SELECT id, ingredient_name, quantity, unit FROM meal_ingredients WHERE meal_id = :mealId",
                { mealId = meal.id },
                { datasource = variables.datasource }
            );
            for (var j = 1; j <= ingrQ.recordCount; j++) {
                arrayAppend(meal.ingredients, {
                    id              : ingrQ.id[j],
                    ingredient_name : ingrQ.ingredient_name[j],
                    quantity        : ingrQ.quantity[j],
                    unit            : ingrQ.unit[j]
                });
            }
            arrayAppend(result, meal);
        }
        return result;
    }
    
    /**
     * addMeal()
     * Inserts a new meal with one or more ingredients.
     * @param title       – The meal title.
     * @param servings    – Number of servings.
     * @param ingredients – A JSON string representing an array of ingredient objects.
     */
    remote any function addMeal(required string title, required numeric servings, required string ingredients) {
        var ingredientsArray = deserializeJSON(arguments.ingredients);
        var mealId = 0;
        
        transaction {
            // Insert the meal and capture the generated key.
            var insertMeal = queryExecute(
                "INSERT INTO meals (title, servings, mealType) VALUES (:title, :servings, :mealType)",
                { 
                    title = arguments.title, 
                    servings = arguments.servings,
                    mealType = arguments.mealType 
                },
                { datasource = variables.datasource}
            );

            // Get the last insert ID
                var qLastId = queryExecute(
                    "SELECT LAST_INSERT_ID() AS id",
                    {},
                    { datasource = "sg" }
                );
            mealId = qLastId.id[1];
            
            // Insert each ingredient.
            for (var ingredient in ingredientsArray) {
                queryExecute(
                    "INSERT INTO meal_ingredients (meal_id, ingredient_name, quantity, unit) VALUES (:mealId, :ingName, :quantity, :unit)",
                    {
                        mealId   : mealId,
                        ingName  : ingredient.ingredientName,
                        quantity : ingredient.quantity,
                        unit     : ingredient.unit
                    },
                    { datasource = variables.datasource }
                );
            }
        }
        return { success = true, mealId = mealId };
    }
    
    /**
     * deleteMeal()
     * Deletes a meal (and thanks to ON DELETE CASCADE, its ingredients too).
     */
    remote any function deleteMeal(required numeric mealId) {
        queryExecute(
            "DELETE FROM meals WHERE id = :mealId",
            { mealId = arguments.mealId },
            { datasource = variables.datasource }
        );
        return { success = true };
    }
    
    /**
     * getShoppingList()
     * Aggregates ingredients from selected meals.
     * @param mealIds – JSON string representing an array of selected meal IDs.
     * Performs a simple conversion: if the aggregated quantity of teaspoons reaches 3 or more, it converts to tablespoons.
     */
    remote any function getShoppingList(required string mealIds) {
        // Deserialize the provided JSON of meal IDs.
        var mealIdsArr = deserializeJSON(arguments.mealIds);
        var placeholders = {};
        var placeholderList = "";
        
        // Build dynamic placeholders for the IN clause.
        for (var i = 1; i <= arrayLen(mealIdsArr); i++) {
            placeholders["id" & i] = mealIdsArr[i];
            placeholderList &= (i EQ 1 ? ":id" & i : ", :id" & i);
        }
        
        // Aggregate ingredients by name and unit.
        // This query groups ingredients and sums up their quantities.
        var querySQL = "
             SELECT ingredient_name, unit, SUM(quantity) AS totalQuantity 
             FROM meal_ingredients 
             WHERE meal_id IN (" & placeholderList & ") 
             GROUP BY ingredient_name, unit
        ";
        var ingrList = queryExecute(querySQL, placeholders, { datasource = variables.datasource });
        
        // Use a structure to aggregate rows that differ only by unit formatting.
        var aggregated = {};
        for (var i = 1; i <= ingrList.recordCount; i++) {
            var name     = trim(ingrList.ingredient_name[i]);
            var quantity = ingrList.totalQuantity[i];
            var unit     = lcase(trim(ingrList.unit[i]));
            
            // Normalize cup units so that "cup" and "cups" are treated the same.
            if ( listFindNoCase("cup,cups", unit) ) {
                unit = "cup";
            }
            // Example conversion: if unit is teaspoon(s) and 3 or more are combined, convert to tablespoon(s)
            if ( listFindNoCase("tsp,teaspoon,teaspoons", unit) ) {
                if (quantity >= 3) {
                    var Tbsp = decimalformat(int(quantity / 3) + ((quantity mod 3) / 3));
                    unit = "Tbsp";
                    quantity = Tbsp;
                }
            }
            // Use a composite key of ingredient name and normalized unit.
            var key = name & "|" & unit;
            if (structKeyExists(aggregated, key)) {
                aggregated[key].quantity += quantity;
            } else {
                aggregated[key] = { ingredient = name, quantity = quantity, unit = unit };
            }
        }
        
        // Convert the aggregated structure into an array.
        var outputIngredients = [];
        for (var key in aggregated) {
            arrayAppend(outputIngredients, aggregated[key]);
        }
        
        // Additionally, sum the total servings for selected meal IDs.
        var servingsQuery = queryExecute(
             "SELECT SUM(servings) AS totalServings FROM meals WHERE id IN (" & placeholderList & ")",
             placeholders,
             { datasource = variables.datasource }
        );
        var totalServings = (servingsQuery.recordCount > 0) ? servingsQuery.totalServings[1] : 0;
        var mealsCount = totalServings / 2;
        
        // Return an object with a summary and the ingredients list.
        return { 
            summary: { 
                totalServings: totalServings, 
                meals: mealsCount 
            },
            ingredients: outputIngredients 
        };
    }

    /**
     * getMealById()
     * Retrieves the meal details for selected meal.
     * @param mealIds – JSON string representing an array of selected meal IDs.
     * Performs a database retrieval of the meal and its ingredients.
     */
    remote any function getMealById(required numeric mealId) {
        var mealData = {};
        // Retrieve the meal info.
        var mealQ = queryExecute(
            "SELECT id, title, servings, mealType FROM meals WHERE id = :mealId",
            { mealId = arguments.mealId },
            { datasource = variables.datasource }
        );
        if (mealQ.recordCount > 0) {
            mealData = {
                id         : mealQ.id[1],
                title      : mealQ.title[1],
                servings   : mealQ.servings[1],
                mealType   : mealQ.mealType[1],
                ingredients: []
            };
            // Retrieve associated ingredients.
            var ingrQ = queryExecute(
                "SELECT id, ingredient_name, quantity, unit FROM meal_ingredients WHERE meal_id = :mealId",
                { mealId = arguments.mealId },
                { datasource = variables.datasource }
            );
            for (var i = 1; i <= ingrQ.recordCount; i++) {
                arrayAppend(mealData.ingredients, {
                    id              : ingrQ.id[i],
                    ingredientName  : ingrQ.ingredient_name[i],
                    quantity        : ingrQ.quantity[i],
                    unit            : ingrQ.unit[i]
                });
            }
        }
        return mealData;
    }

    remote any function updateMeal(required numeric mealId, required string title, required numeric servings, required string ingredients) {
        var ingredientsArray = deserializeJSON(arguments.ingredients);
        
        transaction {
            // Update the meal record.
            queryExecute(
                "UPDATE meals SET title = :title, servings = :servings,  mealType = :mealType WHERE id = :mealId",
                { 
                    title = arguments.title, 
                    servings = arguments.servings, 
                    mealType = arguments.mealType, 
                    mealId = arguments.mealId },
                { datasource = variables.datasource }
            );
            
            // Remove all existing ingredients for this meal.
            queryExecute(
                "DELETE FROM meal_ingredients WHERE meal_id = :mealId",
                { mealId = arguments.mealId },
                { datasource = variables.datasource }
            );
            
            // Insert each ingredient again.
            for (var ingredient in ingredientsArray) {
                queryExecute(
                    "INSERT INTO meal_ingredients (meal_id, ingredient_name, quantity, unit) VALUES (:mealId, :ingName, :quantity, :unit)",
                    {
                        mealId   : arguments.mealId,
                        ingName  : ingredient.ingredientName,
                        quantity : ingredient.quantity,
                        unit     : ingredient.unit
                    },
                    { datasource = variables.datasource }
                );
            }
        }
        return { success = true };
    }

    // remote any function getMealIngredients(required numeric mealId) {
    //     var result = [];
    //     var ingredientQry = queryExecute(
    //         "SELECT id, meal_id, ingredient_name, quantity, unit order by ingredient_name asc",
    //         {},
    //         { datasource = variables.datasource }
    //     );
        
    //     for (var i = 1; i <= ingredientQry.recordCount; i++) {
    //         var ingredients = {
    //             id          : ingredientQry.id[i],
    //             meal_id       : ingredientQry.meal_id[i],
    //             ingredient_name    : ingredientQry.ingredient_name[i],
    //             quantity    : ingredientQry.quantity[i],
    //             unit  : ingredientQry.unit[i]
    //         };

    //         arrayAppend(ingredients);
    //     }
    //     return result;
    // }

    remote any function getMealIngredients(required string mealIds) {
        var result = []; // Initialize an empty array
        // Build the SQL using the IN clause.
        // The list attribute in the options ensures that the mealIds parameter (a comma-separated list)
        // is properly expanded into multiple values.
        var sql = "
            SELECT id, meal_id, ingredient_name, quantity, unit
            FROM meal_ingredients
            WHERE meal_id IN (:mealIds)
            ORDER BY ingredient_name ASC
        ";
        
        var ingredientQry = queryExecute(
            sql,
            { mealIds: { value: arguments.mealIds, cfsqltype: "cf_sql_integer", list:"true" }},
            { datasource = variables.datasource, list = true }
        );

        for (var i = 1; i <= ingredientQry.recordCount; i++) {
            var ingredientData = {
                id              : ingredientQry.id[i],
                meal_id         : ingredientQry.meal_id[i],
                ingredient : ingredientQry.ingredient_name[i],
                quantity        : ingredientQry.quantity[i],
                unit            : ingredientQry.unit[i]
            };
            arrayAppend(result, ingredientData);
        }

        return result;
    }

}
