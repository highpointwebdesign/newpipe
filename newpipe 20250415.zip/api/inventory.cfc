component {

    // GET /api/Inventory.cfc?method=list
    remote function list() httpmethod="GET" returnformat="JSON" {
        var q = queryExecute(
            "SELECT i.id, i.name, inv.current_quantity, i.desired_quantity, i.reorder_threshold
             FROM items i
             JOIN inventory inv ON i.id = inv.item_id
             ORDER BY i.name",
            {},
            { datasource = "sg" }
        );

        var results = [];
        for (var row in q) {
            arrayAppend(results, {
                id = row.id,
                name = row.name,
                current_quantity = row.current_quantity,
                desired_quantity = row.desired_quantity,
                reorder_threshold = row.reorder_threshold
            });
        }

        return results;
    }

    // GET /api/Inventory.cfc?method=get&id=1
    remote function getItem(required numeric id) httpmethod="GET" returnformat="JSON" {
        var item = queryExecute(
            "SELECT i.id, i.name, i.category_id, i.desired_quantity, i.reorder_threshold, inv.current_quantity
             FROM items i
             LEFT JOIN inventory inv ON i.id = inv.item_id
             WHERE i.id = :id",
            { id = arguments.id },
            { datasource = "sg" }
        );
        
        if (item.recordCount == 1) {
            return item.getRow(1);
        } else {
            return { error = "Item not found" };
        }
    }

    // POST /api/Inventory.cfc?method=add
    remote function add(
        required string name,
        required numeric category_id,
        numeric current_quantity = 0,
        numeric desired_quantity = 0,
        numeric reorder_threshold = 0
    ) httpmethod="POST" returnformat="JSON" {
        var result = {};
        
        transaction {
            try {
                // Insert into items table
                queryExecute(
                    "INSERT INTO items (name, category_id, desired_quantity, reorder_threshold)
                     VALUES (:name, :category_id, :desired_quantity, :reorder_threshold)",
                    {
                        name = arguments.name,
                        category_id = arguments.category_id,
                        desired_quantity = arguments.desired_quantity,
                        reorder_threshold = arguments.reorder_threshold
                    },
                    { datasource = "sg" }
                );

                // Get the last insert ID
                var qLastId = queryExecute(
                    "SELECT LAST_INSERT_ID() AS id",
                    {},
                    { datasource = "sg" }
                );
                var itemId = qLastId.id[1];

                // Insert into inventory table
                queryExecute(
                    "INSERT INTO inventory (item_id, current_quantity)
                     VALUES (:item_id, :current_quantity)",
                    {
                        item_id = itemId,
                        current_quantity = arguments.current_quantity
                    },
                    { datasource = "sg" }
                );

                result = { success = true, id = itemId };
            } catch (any e) {
                transaction action="rollback";
                result = { success = false, error = e.message };
            }
        }

        return result;
    }

    // POST /api/Inventory.cfc?method=update&id=1
    remote function updateItem(
        required numeric id,
        required string name,
        required numeric category_id,
        required numeric current_quantity,
        required numeric desired_quantity,
        required numeric reorder_threshold
    ) httpmethod="POST" returnformat="JSON" {
        var result = {};
        
        transaction {
            try {
                // Update items table
                queryExecute(
                    "UPDATE items
                     SET name = :name, category_id = :category_id, desired_quantity = :desired_quantity, reorder_threshold = :reorder_threshold
                     WHERE id = :id",
                    {
                        id = arguments.id,
                        name = arguments.name,
                        category_id = arguments.category_id,
                        desired_quantity = arguments.desired_quantity,
                        reorder_threshold = arguments.reorder_threshold
                    },
                    { datasource = "sg" }
                );

                // Update inventory table
                queryExecute(
                    "UPDATE inventory
                     SET current_quantity = :current_quantity
                     WHERE item_id = :id",
                    {
                        id = arguments.id,
                        current_quantity = arguments.current_quantity
                    },
                    { datasource = "sg" }
                );

                result = { success = true };
            } catch (any e) {
                transaction action="rollback";
                result = { success = false, error = e.message };
            }
        }

        return result;
    }


    // POST /api/Inventory.cfc?method=delete&id=1
    remote function deleteItem(required numeric id) httpmethod="POST" returnformat="JSON" {
        queryExecute(
            "DELETE FROM inventory WHERE item_id = :id",
            { id = arguments.id },
            { datasource = "sg" }
        );

        queryExecute(
            "DELETE FROM items WHERE id = :id",
            { id = arguments.id },
            { datasource = "sg" }
        );

        return { success = true };
    }

    remote function getCategories() httpmethod="GET" returnformat="JSON" {
        var categories = queryExecute(
            "SELECT id, name FROM categories ORDER BY name",
            {},
            { datasource = "sg" }
        );
        
        return categories;
    }

    // shopping list
    remote function getShoppingList() httpmethod="GET" returnformat="JSON" {
        var shoppingList = queryExecute(
            "SELECT c.name AS category_name, i.id, i.name, i.desired_quantity, inv.current_quantity, 
                (i.desired_quantity - inv.current_quantity) AS quantity_to_buy
             FROM items i
             JOIN categories c ON i.category_id = c.id
             JOIN inventory inv ON i.id = inv.item_id
             WHERE inv.current_quantity < i.desired_quantity
             ORDER BY c.name, i.name",
            {},
            {datasource = "sg"}
        );
        return shoppingList;
    }

}