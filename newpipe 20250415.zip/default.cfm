<!--- index.cfm --->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Inventory Management</h1>
        <div class="mb-3">
            <div class="btn-group" role="group" aria-label="Inventory actions">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addItemModal">
                    Add New Item
                </button>
                <a href="shoppingList.cfm" class="btn btn-success">View Shopping List</a>
            </div>
        </div>        

        <table class="table table-striped table-hover" id="inventoryTable">
            <thead class="table-dark">
                <tr>
                    <th>Item</th>
                    <th>Current Quantity</th>
                    <th>Desired Quantity</th>
                    <th>Reorder Threshold</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap 5 JS Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Your custom JS -->
    <script src="js/default.js"></script>

    <!-- Add Item Modal -->
    <div class="modal fade" id="addItemModal" tabindex="-1" aria-labelledby="addItemModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="addItemModalLabel">Add New Item</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="addItemForm">
              <div class="mb-3">
                <label for="itemName" class="form-label">Item Name</label>
                <input type="text" class="form-control" id="itemName" required>
              </div>
              <div class="mb-3">
                <label for="itemCategory" class="form-label">Category</label>
                <select class="form-select" id="itemCategory" required>
                    <option value="">Select a category</option>
                    <!-- Categories will be populated here -->
                </select>
              </div>
              <div class="mb-3">
                <label for="currentQuantity" class="form-label">Current Quantity</label>
                <input type="number" class="form-control" id="currentQuantity" required>
              </div>
              <div class="mb-3">
                <label for="desiredQuantity" class="form-label">Desired Quantity</label>
                <input type="number" class="form-control" id="desiredQuantity" required>
              </div>
              <div class="mb-3">
                <label for="reorderThreshold" class="form-label">Reorder Threshold</label>
                <input type="number" class="form-control" id="reorderThreshold" required>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary" id="saveNewItem">Save Item</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Edit Item Modal -->
    <div class="modal fade" id="editItemModal" tabindex="-1" aria-labelledby="editItemModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editItemModalLabel">Edit Item</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="editItemForm">
              <input type="hidden" id="editItemId">
              <div class="mb-3">
                <label for="editItemName" class="form-label">Item Name</label>
                <input type="text" class="form-control" id="editItemName" required>
              </div>
              <div class="mb-3">
                <label for="editItemCategory" class="form-label">Category</label>
                <select class="form-select" id="editItemCategory" required>
                  <option value="">Select a category</option>
                </select>
              </div>
              <div class="mb-3">
                <label for="editCurrentQuantity" class="form-label">Current Quantity</label>
                <input type="number" class="form-control" id="editCurrentQuantity" required>
              </div>
              <div class="mb-3">
                <label for="editDesiredQuantity" class="form-label">Desired Quantity</label>
                <input type="number" class="form-control" id="editDesiredQuantity" required>
              </div>
              <div class="mb-3">
                <label for="editReorderThreshold" class="form-label">Reorder Threshold</label>
                <input type="number" class="form-control" id="editReorderThreshold" required>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary" id="saveEditButton">Save changes</button>
          </div>
        </div>
      </div>
    </div>
</body>
</html>