$(document).ready(function() {
  // Event delegation for add buttons
  $('#addItemBtn').click(function() {
    $('#addItemModal').modal('show');
  });
  // Event delegation for edit buttons
  $('#inventoryTable').on('click', '.edit-item', function() {
    var itemId = $(this).data('id');
    openEditModal(itemId);
  });
  // Event delegation for delete buttons
  $('#saveEditButton').on('click', function() {
    saveEditedItem();
  });
  // Event delegation for delete buttons
  $('#inventoryTable').on('click', '.delete-item', function() {
    var itemId = $(this).data('id');
    if (confirm('Are you sure you want to delete this item?')) {
      deleteItem(itemId);
    }
  });  
  


  $('#addItemModal').on('hidden.bs.modal', function (e) {
    $(this).find('button, input, textarea, select').blur();
  });
  $('#editItemModal').on('hidden.bs.modal', function (e) {
    $(this).find('button, input, textarea, select').blur();
  });
  
  // Handle form submission
  $('#saveNewItem').click(function() {
      var newItem = {
          name: $('#itemName').val(),
          current_quantity: parseInt($('#currentQuantity').val()),
          desired_quantity: parseInt($('#desiredQuantity').val()),
          reorder_threshold: parseInt($('#reorderThreshold').val()),
          category_id: parseInt($('#itemCategory').val())
      };

      $.ajax({
          url: 'api/inventory.cfc?method=add',
          method: 'POST',
          data: newItem,
          dataType: 'json',
          success: function(response) {
              if (response.success) {
                  $('#addItemModal').modal('hide');
                  loadItems(); // Reload the inventory table
                  // Clear the form
                  $('#addItemForm')[0].reset();
              } else {
                  alert('Error adding item');
              }
          },
          error: function(xhr, status, error) {
              console.error('Error adding item:', error);
              alert('Error adding item');
          }
      });
  });

  $('#addItemModal').on('show.bs.modal', function (e) {
      // Fetch categories and populate the select box
      $.ajax({
          url: 'api/inventory.cfc?method=getCategories',
          method: 'GET',
          dataType: 'json',
          success: function(response) {
              var categorySelect = $('#itemCategory');
              categorySelect.find('option:not(:first)').remove(); // Clear existing options
              
              // Check if response has the expected structure
              if (response.COLUMNS && response.DATA) {
                  var idIndex = response.COLUMNS.indexOf("id");
                  var nameIndex = response.COLUMNS.indexOf("name");
                  
                  if (idIndex !== -1 && nameIndex !== -1) {
                      response.DATA.forEach(function(category) {
                          categorySelect.append($('<option>', {
                              value: category[idIndex],
                              text: category[nameIndex]
                          }));
                      });
                  }
              }
          },
          error: function(xhr, status, error) {
              console.error('Error fetching categories:', error);
          }
      });
  });

  function openEditModal(itemId) {
      console.log('Opening edit modal for item ID:', itemId);
      
      // First, fetch categories
      $.ajax({
          url: 'api/inventory.cfc?method=getCategories',
          method: 'GET',
          dataType: 'json',
          success: function(response) {
              console.log('Categories received:', response);
              
              // Parse the ColdFusion query result structure
              var categories = response.DATA.map(function(row, index) {
                  return {
                      id: row[0],
                      name: row[1]
                  };
              });
              
              // Populate category dropdown
              var categorySelect = $('#editItemCategory');
              categorySelect.empty();
              categorySelect.append('<option value="">Select a category</option>');
              $.each(categories, function(index, category) {
                  categorySelect.append($('<option></option>').val(category.id).text(category.name));
              });
              
              // Now fetch the item details
              $.ajax({
                  url: 'api/inventory.cfc?method=getItem',
                  method: 'GET',
                  data: { id: itemId },
                  dataType: 'json',
                  success: function(response) {
                      console.log('Item data received:', response);
                      
                      $('#editItemId').val(response.id);
                      $('#editItemName').val(response.name);
                      $('#editItemCategory').val(response.category_id);
                      $('#editCurrentQuantity').val(response.current_quantity);
                      $('#editDesiredQuantity').val(response.desired_quantity);
                      $('#editReorderThreshold').val(response.reorder_threshold);
                      
                      // Open the modal
                      var editModal = new bootstrap.Modal(document.getElementById('editItemModal'));
                      editModal.show();
                      console.log('Modal should be visible now');
                  },
                  error: function(xhr, status, error) {
                      console.error('Error fetching item details:', error);
                  }
              });
          },
          error: function(xhr, status, error) {
              console.error('Error fetching categories:', error);
          }
      });
  }

  function saveEditedItem() {
      var updatedItem = {
          id: $('#editItemId').val(),
          name: $('#editItemName').val(),
          category_id: $('#editItemCategory').val(),
          current_quantity: $('#editCurrentQuantity').val(),
          desired_quantity: $('#editDesiredQuantity').val(),
          reorder_threshold: $('#editReorderThreshold').val()
      };

      $.ajax({
          url: 'api/inventory.cfc?method=updateItem',
          method: 'POST',
          data: updatedItem,
          dataType: 'json',
          success: function(response) {
              console.log('Item updated successfully:', response);
              
              // Close the modal
              var editModal = bootstrap.Modal.getInstance(document.getElementById('editItemModal'));
              editModal.hide();

              // Refresh the main display
              loadItems();

              // Optionally, show a success message
              alert('Item updated successfully!');
          },
          error: function(xhr, status, error) {
              console.error('Error updating item:', error);
              alert('Error updating item. Please try again.');
          }
      });
  } 

  function deleteItem(itemId) {
      $.ajax({
          url: 'api/inventory.cfc?method=deleteItem',
          method: 'POST',
          data: { id: itemId },
          dataType: 'json',
          success: function(response) {
              console.log('Item deleted successfully:', response);
              
              // Remove the item from the display
              $(`#inventoryTable button[data-id="${itemId}"]`).closest('tr').remove();
              
              // Alternatively, refresh the entire list
              // loadItems();

              // Optionally, show a success message
              alert('Item deleted successfully! 241');
          },
          error: function(xhr, status, error) {
              console.error('Error deleting item:', error);
              alert('Error deleting item. Please try again.');
          }
      });
  }   

  function loadItems() {
    $.ajax({
        url: 'api/inventory.cfc?method=list',
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            const tbody = $('#inventoryTable tbody');
            tbody.empty();
            
            response.forEach(item => {
                const row = `
                    <tr>
                        <td>${item.name}</td>
                        <td>${item.current_quantity}</td>
                        <td>${item.desired_quantity}</td>
                        <td>${item.reorder_threshold}</td>
                        <td>
                            <button class="btn btn-sm btn-primary edit-item" data-id="${item.id}">Edit</button>
                            <button class="btn btn-sm btn-danger delete-item" data-id="${item.id}">Delete</button>
                        </td>
                    </tr>
                `;
                tbody.append(row);
            });
        },
        error: function(xhr, status, error) {
            console.error('Error fetching inventory:', error);
        }
    });
  }

  // function openEditModal(itemId) {
  //     // Fetch item details and populate the form
  //     $.ajax({
  //         url: '/api/inventory.cfc?method=getItem',
  //         method: 'GET',
  //         data: { id: itemId },
  //         dataType: 'json',
  //         success: function(response) {
  //             $('#editItemId').val(response.id);
  //             $('#editItemName').val(response.name);
  //             $('#editItemCategory').val(response.category_id);
  //             $('#editCurrentQuantity').val(response.current_quantity);
  //             $('#editDesiredQuantity').val(response.desired_quantity);
  //             $('#editReorderThreshold').val(response.reorder_threshold);
              
  //             // Show the modal
  //             $('#editItemModal').modal('show');
  //         },
  //         error: function(xhr, status, error) {
  //             console.error('Error fetching item details:', error);
  //         }
  //     });
  // }

  function updateItem() {
      var itemId = $('#editItemId').val();
      var itemName = $('#editItemName').val();
      var categoryId = $('#editItemCategory').val();
      var currentQuantity = $('#editCurrentQuantity').val();
      var desiredQuantity = $('#editDesiredQuantity').val();
      var reorderThreshold = $('#editReorderThreshold').val();

      $.ajax({
          url: '/api/inventory.cfc?method=update',
          method: 'POST',
          data: {
              id: itemId,
              name: itemName,
              category_id: categoryId,
              current_quantity: currentQuantity,
              desired_quantity: desiredQuantity,
              reorder_threshold: reorderThreshold
          },
          dataType: 'json',
          success: function(response) {
              if (response.success) {
                  $('#editItemModal').modal('hide');
                  loadItems(); // Refresh the item list
              } else {
                  alert('Error updating item: ' + response.error);
              }
          },
          error: function(xhr, status, error) {
              alert('Error updating item: ' + error);
          }
      });
  }

  // Modify your existing code to call openEditModal when the edit button is clicked
  // function loadItems() {
  //     $.ajax({
  //         url: '/api/inventory.cfc?method=list',
  //         method: 'GET',
  //         dataType: 'json',
  //         success: function(response) {
  //             var itemList = $('#itemList');
  //             itemList.empty();
  //             $.each(response, function(index, item) {
  //                 itemList.append(`
  //                     <tr>
  //                         <td>${item.name}</td>
  //                         <td>${item.category}</td>
  //                         <td>${item.current_quantity}</td>
  //                         <td>${item.desired_quantity}</td>
  //                         <td>${item.reorder_threshold}</td>
  //                         <td>
  //                             <button class="btn btn-sm btn-primary" onclick="openEditModal(${item.id})">Edit</button>
  //                             <button class="btn btn-sm btn-danger" onclick="deleteItem(${item.id})">Delete</button>
  //                         </td>
  //                     </tr>
  //                 `);
  //             });
  //         },
  //         error: function(xhr, status, error) {
  //             console.error('Error loading items:', error);
  //         }
  //     });
  // }

  // Initial load
  loadItems();

  // Additional event handlers (e.g., for editing items) can be added here
});