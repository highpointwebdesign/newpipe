$(document).ready(function() {
    loadShoppingList();
});

function loadShoppingList() {
    $.ajax({
        url: 'api/inventory.cfc?method=getShoppingList',
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            const shoppingListContainer = $('#shoppingList');
            shoppingListContainer.empty();

            let currentCategory = '';
            let categoryList = null;

            response.DATA.forEach((item, index) => {
                const category = item[0];
                const itemId = item[1];
                const itemName = item[2];
                const quantityToBuy = item[5];

                if (category !== currentCategory) {
                    currentCategory = category;
                    shoppingListContainer.append(`<h2>${category}</h2>`);
                    categoryList = $('<ul class="list-group mb-3"></ul>');
                    shoppingListContainer.append(categoryList);
                }

                const listItem = $(`
                    <li class="list-group-item">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="item-${itemId}">
                            <label class="form-check-label" for="item-${itemId}">
                                ${itemName} (${quantityToBuy})
                            </label>
                        </div>
                    </li>
                `);

                categoryList.append(listItem);
            });

            // Add event listener for checkboxes
            $('.form-check-input').on('change', function() {
                $(this).closest('.list-group-item').toggleClass('completed', this.checked);
            });
        },
        error: function(xhr, status, error) {
            console.error('Error fetching shopping list:', error);
        }
    });
}