<cfscript>
q = new Query();
q.setDatasource("sg");
q.setSQL("SELECT NOW() AS currentTime");
result = q.execute().getResult();
writeDump(result);
</cfscript>